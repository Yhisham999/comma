const express = require("express");
const db = require("../db");
const router = express.Router();

// Fetch all shared area check-ins with customer names
router.get("/shared-area-checkins", async (req, res) => {
  try {
    const [checkIns] = await db.query(`
        SELECT 
          shared_area_checkins.*, 
          customers.name AS customer_name 
        FROM shared_area_checkins 
        LEFT JOIN customers ON shared_area_checkins.customer_id = customers.id
      `);
    res.json(checkIns);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});
router.get("/", async (req, res) => {
  try {
    const [checkIns] = await db.query(`
        SELECT 
          shared_area_checkins.*, 
          customers.name AS name 
        FROM shared_area_checkins 
        LEFT JOIN customers ON shared_area_checkins.customer_id = customers.id
      `);
    res.json(checkIns);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Fetch a single shared area check-in by ID with customer name
router.get("/:id", async (req, res) => {
  try {
    const [rows] = await db.query(
      `
      SELECT shared_area_checkins.*, customers.name AS name 
      FROM shared_area_checkins 
      LEFT JOIN customers ON shared_area_checkins.customer_id = customers.id 
      WHERE shared_area_checkins.id = ?
    `,
      [req.params.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: "Check-in not found" });
    }
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Check-in a customer to the shared area
router.post("/check-in", async (req, res) => {
  const { customer_id } = req.body;

  try {
    // 1. Check if the customer exists
    const [customer] = await db.query("SELECT * FROM customers WHERE id = ?", [
      customer_id,
    ]);
    if (customer.length === 0) {
      return res.status(404).json({ message: "Customer not found" });
    }

    // 2. Start Transaction
    const connection = await db.getConnection();
    await connection.beginTransaction();

    try {
      // 3. Insert into shared_area_checkins
      const [result] = await connection.query(
        "INSERT INTO shared_area_checkins (customer_id, check_in_time, status, customer_name) VALUES (?, NOW(), 'active', ?)",
        [customer_id, customer[0].name]
      );

      // 4. Insert into active_shared_area_customers
      const [activeCustomerInsert] = await connection.query(
        "INSERT INTO active_shared_area_customers (customer_id, name, phone, check_in_time) VALUES (?, ?, ?, NOW())",
        [customer_id, customer[0].name, customer[0].phone]
      );

      if (activeCustomerInsert.affectedRows === 0) {
        throw new Error("Failed to insert into active_shared_area_customers");
      }

      // 5. Commit Transaction
      await connection.commit();
      connection.release();

      // 6. Fetch and return the updated active customers list
      const [activeCustomers] = await db.query(
        "SELECT * FROM active_shared_area_customers"
      );
      res.status(201).json({
        message: "Check-in successful",
        checkInId: result.insertId,
        activeCustomers, // Return updated active customers list
      });
    } catch (err) {
      await connection.rollback();
      connection.release();
      throw err;
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Check-out a customer from the shared area
router.put("/check-out/:id", async (req, res) => {
  const { id } = req.params;
  const { kitchen_items } = req.body;

  try {
    // 1. Get the check-in details
    const [checkIn] = await db.query(
      "SELECT * FROM shared_area_checkins WHERE id = ?",
      [id]
    );
    if (checkIn.length === 0) {
      return res.status(404).json({ message: "Check-in not found" });
    }

    // 2. Calculate total time and cost
    const checkInTime = new Date(checkIn[0].check_in_time);
    const checkOutTime = new Date();
    const totalTime = Math.round((checkOutTime - checkInTime) / (1000 * 60)); // in minutes
    const sharedAreaPrice = 10; // Example: $10 per hour for shared area
    const timeCost = totalTime * (sharedAreaPrice / 60);
    const itemsCost = await calculateKitchenItemsCost(kitchen_items);
    const totalCost = timeCost + itemsCost;

    // 3. Update the shared_area_checkins table
    await db.query(
      "UPDATE shared_area_checkins SET check_out_time = NOW(), total_time = ?, total_cost = ?, status = 'checked_out' WHERE id = ?",
      [totalTime, totalCost, id]
    );

    // 4. Remove from active_shared_area_customers table
    await db.query(
      "DELETE FROM active_shared_area_customers WHERE customer_id = ?",
      [checkIn[0].customer_id]
    );

    // 5. Return updated check-in details
    const [updatedCheckIn] = await db.query(
      `SELECT shared_area_checkins.*, customers.name AS name 
       FROM shared_area_checkins 
       LEFT JOIN customers ON shared_area_checkins.customer_id = customers.id 
       WHERE shared_area_checkins.id = ?`,
      [id]
    );

    res.json(updatedCheckIn[0]);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Cancel a shared area check-in
router.delete("/:id", async (req, res) => {
  const { reason } = req.body;

  try {
    const [result] = await db.query(
      "UPDATE shared_area_checkins SET status = 'cancelled', cancellation_reason = ? WHERE id = ?",
      [reason, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Check-in not found" });
    }

    // Fetch the updated check-in with customer name
    const [updatedCheckIn] = await db.query(
      `
      SELECT shared_area_checkins.*, customers.name AS name 
      FROM shared_area_checkins 
      LEFT JOIN customers ON shared_area_checkins.customer_id = customers.id 
      WHERE shared_area_checkins.id = ?
    `,
      [req.params.id]
    );

    res.json(updatedCheckIn[0]);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Fetch active shared area customers
router.get("/active-customers", async (req, res) => {
  try {
    const [activeCustomers] = await db.query(`
      SELECT ac.*, c.email 
      FROM active_shared_area_customers ac
      JOIN customers c ON ac.customer_id = c.id
    `);
    res.json(activeCustomers);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Helper function: Calculate kitchen items cost
async function calculateKitchenItemsCost(kitchenItems) {
  if (!kitchenItems || kitchenItems.length === 0) return 0;

  const [items] = await db.query(
    "SELECT price FROM kitchen_items WHERE id IN (?)",
    [kitchenItems]
  );

  return items.reduce((total, item) => total + item.price, 0);
}

module.exports = router;
